import java.util.HashSet;

public class SweetSet<E> extends HashSet<E>{

	private static final long serialVersionUID = 1L;

	/**
	 * overide the string to properly display the emails (or at least supposed)
	 */
	@Override
	public String toString() {
		String emails = "";
		while (this.iterator().hasNext())
			emails.concat(String.valueOf(this.iterator().next()) + "\n");
		return emails;
	}
}
