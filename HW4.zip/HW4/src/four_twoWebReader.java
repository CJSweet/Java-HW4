import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class four_twoWebReader implements Runnable {

	URL url;
	static int i = 0;
	
	public four_twoWebReader(String url) {
		try {
			this.url = new URL(url);
		} catch (Exception ex) {
			url = null;
		}
		four_twoGUI.urls.replace(url, true);
	}
	
	/**
	 * read the webpage to look for emails and links
	 */
	@Override
	public void run() {
		if( url == null) return;
		try {
			BufferedReader rdr = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			Pattern email = Pattern.compile("mailto:(.*?)\"");
			Pattern readurl = Pattern.compile("www.(.*?)\"");
			while ((line = rdr.readLine()) != null) {
				
				Matcher emailMatch = email.matcher(line);
				Matcher readMatch = readurl.matcher(line);
				
				if(emailMatch.find()) {
					System.out.println("Email: " + emailMatch.group(1));
					four_twoGUI.emails.add(emailMatch.group(1));
				}
					
				else if(readMatch.find()) {
					if (i >= 100) {
						break;
					}
					else {
						i++;
						System.out.println("URL: "+ i + " " + readMatch.group(1));
						String web = "https://" + readMatch.group(1).toString();
						four_twoGUI.urls.put(web, false);
					}
				}
			}
				rdr.close();
		} catch (Exception ex) {
			System.out.printf(ex.getMessage() + "\n");
		}	
	}
}
