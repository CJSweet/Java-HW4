import java.awt.Image;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

import java.util.ArrayList;
import java.util.Random;
/**
 * @author csweet20
 * HW4
 * Tucker
 * CS-372-Java
 */
public class four_oneRunnable implements Runnable{
	 
	JLabel label;
	public static ArrayList<ImageIcon> imagesI = new ArrayList<ImageIcon>();
	
	/**
	 * @param i is the JLabel that will be manipulated
	 * @param image is the ArrayList of ImageIcons that will be used
	 */
	four_oneRunnable(JLabel i, ArrayList<ImageIcon> image){
		label = i;
		for (int in = 0; in < image.size(); in++) {
			Image m = image.get(in).getImage();
			imagesI.add(new ImageIcon(m));
		}
	}
	
	/**
	 * overriden run function that will change the image of the label the size of the image ArrayList times
	 */
	@Override
	public void run() {
		Random rand = new Random();
		for(int i = 0; i < imagesI.size(); i++) {
			int n = rand.nextInt(imagesI.size()); ///random number generated to select in images Array
			label.setIcon(new ImageIcon(imagesI.get(n).getImage()));
			try {
				Thread.sleep(500);
			}catch(InterruptedException ex) {
				System.out.print("oh no");
			}
			if (i == (imagesI.size() - 1)) /// if statement to see if I could find the sum
				four_oneYahtzee.s = four_oneYahtzee.s + n;
		}
	}
}
