import java.awt.EventQueue;

import javax.swing.JFrame;
		import java.awt.FlowLayout;
		import java.awt.Image;
		import java.io.IOException;
		import java.lang.Thread;
		import java.net.URL;
		import java.util.ArrayList;

		import javax.imageio.ImageIO;
		import javax.swing.ImageIcon;
		import javax.swing.JFrame;
		import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
/**	
 * @author csweet20
 *	HW4
 *	Tucker
 *	CS-372-Java
 */
		
		
public class four_oneYahtzee {

	private JFrame frame = new JFrame();
	ArrayList<JLabel> labels = new ArrayList<JLabel>(); ///for the 5 labels
	public static ArrayList<ImageIcon> images = new ArrayList<ImageIcon>(); //for the 6 images
	four_oneRunnable[] pics = new four_oneRunnable[5]; ///for each thread for each label
	private final JPanel dicePanel = new JPanel();
	public static int s = 0;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					four_oneYahtzee window = new four_oneYahtzee();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public four_oneYahtzee() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * this is where the images are found, and the Runnable objects are created and Thread made
	 */
	private void initialize() {
		
		try {
			URL one = new URL("http://dobbelsteen.virtuworld.net/img/1c.gif");
			Image oneImage = ImageIO.read(one);
			images.add(new ImageIcon(oneImage));
		} catch (IOException e) {
				System.out.printf("oops");
		}
					
		try {
			URL two = new URL("http://dobbelsteen.virtuworld.net/img/2c.gif");
			Image twoImage = ImageIO.read(two);
			images.add(new ImageIcon(twoImage));
		} catch (IOException e) {
			System.out.printf("oops");
		}
				
		try {
			URL three = new URL("http://dobbelsteen.virtuworld.net/img/3c.gif");
			Image threeImage = ImageIO.read(three);
			images.add(new ImageIcon(threeImage));
		} catch (IOException e) {
			System.out.printf("oops");
		}
			
		try {
			URL four = new URL("http://dobbelsteen.virtuworld.net/img/4c.gif");
			Image fourImage = ImageIO.read(four);
			images.add(new ImageIcon(fourImage));
		} catch (IOException e) {
			System.out.printf("oops");
			}
				
		try {
			URL five = new URL("http://dobbelsteen.virtuworld.net/img/5c.gif");
			Image fiveImage = ImageIO.read(five);
			images.add(new ImageIcon(fiveImage));
		} catch (IOException e) {
			System.out.printf("oops");
		}
			
		try {
			URL six = new URL("http://dobbelsteen.virtuworld.net/img/6c.gif");
			Image sixImage = ImageIO.read(six);
			images.add(new ImageIcon(sixImage));
		} catch (IOException e) {
			System.out.printf("oops");
		}
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1014, 638);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		frame.setSize(958,800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dicePanel.setBounds(0, 0, 942, 761);
		
		frame.getContentPane().add(dicePanel);
		dicePanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		
		///for loop for creating new labels and creating Runnable objects
		for(int i = 0; i < pics.length; i++) {
			JLabel l = new JLabel();
			pics[i] = new four_oneRunnable(l, images);
			labels.add(l);
			dicePanel.add(l);
		}
		
		//// for loop to start every thread
		for(int i = 0; i < pics.length; i++) {
			Thread t = new Thread(pics[i]);
			t.start();
			try {
				Thread.sleep(1000);
			} catch(InterruptedException ex) {;}
		}

		
		//my attempt to find the sum of the numbers
		JLabel sumL = new JLabel(String.valueOf(s));
		dicePanel.add(sumL);
	}
}
