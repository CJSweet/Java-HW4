import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.util.*;

public class four_twoGUI {

	private JFrame frame;
	public static HashMap<String, Boolean> urls = new HashMap<>();
	public static SweetSet<String> emails = new SweetSet<>();
	private String[] webpages = {
			"https://www.kxly.com/station/contact-kxly/171599929", "https://katu.com/amnw/contact-amnw"};
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					four_twoGUI window = new four_twoGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {e.printStackTrace();}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public four_twoGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 841, 666);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 805, 605);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JTextArea emailList = new JTextArea();
		emailList.setLineWrap(true);
		emailList.setBounds(22, 150, 758, 444);
		panel.add(emailList);
		
		JLabel EmailLabel = new JLabel("Emails:");
		EmailLabel.setHorizontalAlignment(SwingConstants.CENTER);
		EmailLabel.setBounds(88, 58, 624, 64);
		panel.add(EmailLabel);
		
		////////////////////////////////////////////////////////////////////////////////
		
		four_twoWebReader[] wr = new four_twoWebReader[webpages.length];
		for(int i = 0; i < wr.length; i++) {
			wr[i] = new four_twoWebReader(webpages[i]);
		}
		
		Thread[] ts = new Thread[webpages.length];
		for (int i = 0; i < ts.length; i++) {
			ts[i] = new Thread(wr[i]);
			ts[i].start();
		}
		
		while (ts[1].isAlive()) {
			///waiting to print text till after both threads are done
		}
		emailList.setText(emails.toString());
	}
}
