package com.sweet.four_threeyahtzee;

import android.widget.ImageView;
import java.util.Random;

/**
 * @author csweet20
 * HW4
 * Tucker
 * CS-372-JAVA
 */
public class Threads implements Runnable {

    ImageView diceLabel;

    Threads(ImageView i){
        diceLabel = i; ///only need to take ImageView
    }

    /**
     * changes the given labels images 30 times
     */
    @Override
    public void run(){
        ///rand num generator, and the for loop to keep switching images
        Random rand = new Random();
        for(int i = 0; i< 30; i++){
            int n = rand.nextInt(MainActivity.images.size());
            diceLabel.setImageDrawable(MainActivity.images.get(n));
            try{
                Thread.sleep(300);
            }catch(InterruptedException ex){ }
        }
    }
}
