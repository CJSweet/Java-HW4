package com.sweet.four_threeyahtzee;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import java.util.ArrayList;
import android.widget.Button;

/**
 * @author csweet20
 * HW4
 * Tucker
 * CS-372-Java
 */
public class MainActivity extends AppCompatActivity {

    static ArrayList<ImageView> views = new ArrayList<>();
    static ArrayList<Drawable> images = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ///put all ImageViews in one arraylist
        ImageView firstI = findViewById(R.id.first);
        views.add(firstI);
        ImageView secondI = findViewById(R.id.second);
        views.add(secondI);
        ImageView threeI = findViewById(R.id.three);
        views.add(threeI);
        ImageView fourI = findViewById(R.id.four);
        views.add(fourI);
        ImageView fiveI = findViewById(R.id.five);
        views.add(fiveI);

        //add all Drawables (images) to the arraylist
        images.add(getDrawable(R.drawable.firstdie));
        images.add(getDrawable(R.drawable.twodie));
        images.add(getDrawable(R.drawable.threedie));
        images.add(getDrawable(R.drawable.fourdie));
        images.add(getDrawable(R.drawable.fivedie));
        images.add(getDrawable(R.drawable.sixdie));

        ///Array of Threads (one for every label)
        final Threads[] funct = new Threads[5];
        for (int i = 0; i < funct.length; i++) {
            funct[i] = new Threads(views.get(i));
        }
        ///Button to start
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                {   ///starts every thread running
                    for (int i = 0; i < views.size(); i++) {
                        Thread t = new Thread(funct[i]);
                        t.start();
                        try {
                           Thread.sleep(100);
                        } catch (InterruptedException ex) {
                        }
                    }
                }
            }
        });
    }
}
